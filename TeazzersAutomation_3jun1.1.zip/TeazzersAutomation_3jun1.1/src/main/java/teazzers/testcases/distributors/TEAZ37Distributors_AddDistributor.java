package teazzers.testcases.distributors;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.AddNewParentCompanyPage;
import teazzers.pages.EditParentCompanypage;
import teazzers.pages.LoginPage;
import teazzers.pages.ManageParentCompaniespage;

public class TEAZ37Distributors_AddDistributor extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Add New Distributor";
		testCaseDescription = "Adding new Distributor record and verifying whether it is added successfully";
		author = "Suganya";
		excelfile="TEAZ037_Distri_AddDistribtr";
	}
	@Test(dataProvider = "getdata")
	public void AddDistributor(String url,String uName, String Pwd,String name,String tradenme) throws InterruptedException {
		new LoginPage(driver, eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners().clickDistributors();
		new ManageParentCompaniespage(driver, eachNode).clickAddbtn().enterName(name);
		new EditParentCompanypage(driver, eachNode).enterTradeName(tradenme);
		new AddNewParentCompanyPage(driver, eachNode).clickSaveBtn().clickParentCompaniesTab().clickDistributors();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(name).clickSearchIcon();
}

}

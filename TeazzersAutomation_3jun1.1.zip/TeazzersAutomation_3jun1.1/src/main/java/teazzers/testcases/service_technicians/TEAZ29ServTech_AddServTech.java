package teazzers.testcases.service_technicians;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;
import teazzers.pages.ManageParentCompaniespage;

public class TEAZ29ServTech_AddServTech extends ProjSpecificMethods{
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Add New Service Technician";
		testCaseDescription = "Adding new Service Technician record and verifying whether it is added successfully";
		author = "Suganya";
		excelfile="TEAZ008_AddNewParent_NoOwner";
	}
	@Test(dataProvider = "getdata")
	public void AddServTechn(String url,String uName, String Pwd,String name) throws InterruptedException {
		new LoginPage(driver, eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners().clickServiceTechn();
		new ManageParentCompaniespage(driver, eachNode).clickAddbtn().enterName(name).clickSaveBtn().clickParentCompaniesTab().clickServiceTechn();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(name).clickSearchIcon();
}

}

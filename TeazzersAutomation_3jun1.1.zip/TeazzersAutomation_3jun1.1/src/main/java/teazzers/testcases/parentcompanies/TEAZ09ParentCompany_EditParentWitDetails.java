package teazzers.testcases.parentcompanies;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ09ParentCompany_EditParentWitDetails extends ProjSpecificMethods
{
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Edit Parent Record in Parent Company Module";
		testCaseDescription = "Editing the Prent record and verifying the changes are updated";
		author = "Suganya";
		excelfile="TEAZ009_EditParentWitDetails";
	}
	@Test(dataProvider = "getdata")
	public void editParentCompany(String url,String uName, String Pwd, String searchname,String tradename, String phone) throws InterruptedException {
		new LoginPage(driver,eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners().
		enterSearchKeyword(searchname).clickSearchIcon().clickReqRec(searchname).enterTradeName(tradename).enterPhoneNum(phone).
		clickUpdateBtn().clickParentCompaniesTab().enterSearchKeyword(searchname).clickSearchIcon();
		
}
	
}

package teazzers.testcases.parentcompanies;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ05ParentCompany_SearchbyCityName extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Search by City in Parent Company Module";
		testCaseDescription = "Searching using  city name and getting the required records";
		author = "Suganya";
		excelfile="TEAZ005_SearchbyCity";
	}
	@Test(dataProvider = "getdata")
	public void searchCityName(String url,String uName, String Pwd,String searchname) throws InterruptedException {
		new LoginPage(driver,eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners(). 
		enterSearchKeyword(searchname).clickSearchIcon();
	}

}

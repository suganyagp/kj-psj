package teazzers.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.aventstack.extentreports.ExtentTest;
import teazzers.api.ProjSpecificMethods;

public class EditParentCompanypage extends ProjSpecificMethods {
	
	public EditParentCompanypage(RemoteWebDriver driver,ExtentTest eachNode) {
		this.driver=driver;
		this.eachNode = eachNode;
	}
	
	public ManageParentCompaniespage clickParentCompaniesTab() {
		WebElement eleParntCmpy = locateElement("xpath",prop.getProperty("editparntcmpy.clkparntcmpy.xpath"));
		click(eleParntCmpy);
		return new ManageParentCompaniespage(driver,eachNode);
	}
	
	public EditParentCompanypage enterTradeName(String tradenme ) {
		WebElement eleTradName = locateElement("id",prop.getProperty("editparntcmpy.entrtradename.id"));
		clearAndType(eleTradName, tradenme);
		return this;
	}
	public EditParentCompanypage enterPhoneNum(String phne) {
		WebElement elePhoneNum = locateElement("id",prop.getProperty("editparntcmpy.entrphone.id"));
		clearAndType(elePhoneNum, phne);
		return this;
		
	}
	
	public EditParentCompanypage clickUpdateBtn() {
		WebElement eleUpdateBtn = locateElement("xpath",prop.getProperty("editparntcmpy.clkupdate.xpath"));
		click(eleUpdateBtn);
		return this;
	}
	
	public EditParentCompanypage clickCreateUnderAddress() {
		WebElement eleClkAddr = locateElement("id",prop.getProperty("editparntcmpy.clkcreateaddr.id"));
		click(eleClkAddr);
		return this;
	}
	
	public EditParentCompanypage clickAddressdrpdwnBilling(String value) {
		
		WebElement addr = locateElement("xpath",prop.getProperty("editparntcmpy.seldrpwn.xpath"));
		selectDropDownUsingText(addr, value);
		return this;
		
	}
	
	public EditParentCompanypage enterAddressLine1(String addressline) {
		WebElement eleAddrLine = locateElement("id",prop.getProperty("editparntcmpy.entraddr.id"));
		clearAndType(eleAddrLine, addressline);
		return this;
	}
	
	public EditParentCompanypage enterCity(String city) {
		WebElement eleCity = locateElement("id",prop.getProperty("editparntcmpy.entrcity.id"));
		clearAndType(eleCity, city);
		return this;
	}
	
	public EditParentCompanypage enterState(String state) {
		WebElement eleState = locateElement("id",prop.getProperty("editparntcmpy.entrstate.id"));
		clearAndType(eleState, state);
		return this;
	}

	public EditParentCompanypage enterZipcode(String zipcode) {
		WebElement eleZipcode = locateElement("id",prop.getProperty("editparntcmpy.enterzip.id"));
		clearAndType(eleZipcode, zipcode);
		return this;
	}
	
	public EditParentCompanypage clickSaveChangesBtn() throws InterruptedException {
		WebElement eleSaveChge = locateElement("id",prop.getProperty("editparntcmpy.savechanges.id"));
		click(eleSaveChge);
		Thread.sleep(2000);
		return this;
	}
	
	
}

package teazzers.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import teazzers.selenium.api.SeleniumBase;
import teazzers.util.ReadExcel;

public class ProjSpecificMethods extends SeleniumBase  {
	public String excelfile;
	
	
	@BeforeSuite
	public void loadObj() {
		loadObjects();
	}
	
	@BeforeMethod
	public void beforeMethod() {
		eachNode = test.createNode(testCaseName);
		startApp();
	}
	
	@DataProvider
	public String[][] getdata() throws IOException {
		ReadExcel obj= new ReadExcel();
		String[][] readexcel = obj.readExcel(excelfile);
		return readexcel;	
	}

	@AfterMethod
	public void afterMethod() {
		closeBrowser();
	}
	
	@AfterSuite
	public void unloadObj() {
		unloadObjects();
	}

	
	
	


	

}
